ИСПРАВЛЕНИЕ GITHUB ACTIONS ДЛЯ ZOMBIEWAR

В присланном логе запустился стандартный blank.yml на ubuntu-latest.
Он выводит Hello, world! и не компилирует проект.

Скопируйте папку .github из этого архива в корень репозитория GitHub,
согласившись на замену, если GitHub спросит.

Затем в репозитории откройте Actions. Выберите workflow "Build ZombieWar"
и нажмите Run workflow.

ВАЖНО: старый .github/workflows/blank.yml удалите или отключите,
чтобы не путать тестовый workflow с реальной сборкой.

Этот архив содержит только workflow-файл. Он предполагает, что в корне
репозитория уже лежат ZombieWar.csproj, ZombieWar.ini и папка lib,
в которой есть ScriptHookVDotNet3.dll.
